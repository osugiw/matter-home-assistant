## Contributing guide

The issues and the pull-requests are not supported to submit problems or suggestions related to the software delivered in this repository. The STM32WB-BLE-Thread-Matter example is being delivered as-is, not necessarily supported by ST.

For any question related to the product, the hardware performance or characteristics, the tools, the environment, you can submit it to the ST Community on the STM32 MCUs related page.
